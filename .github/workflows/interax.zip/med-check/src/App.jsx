import { useState, useMemo, useEffect } from 'react'
import { Plus, X, AlertTriangle, Info, CheckCircle2, Pill, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { SUBSTANCES, findInteractions, searchSubstances, getById } from '@/lib/interactions'

const SEVERITY_STYLES = {
  major: {
    label: 'Major',
    dot: 'bg-accent',
    ring: 'ring-accent/30',
    border: 'border-accent/40',
    icon: AlertTriangle,
    bg: 'bg-accent/5',
  },
  moderate: {
    label: 'Moderate',
    dot: 'bg-amber',
    ring: 'ring-amber/30',
    border: 'border-amber/40',
    icon: Info,
    bg: 'bg-amber/5',
  },
  minor: {
    label: 'Minor',
    dot: 'bg-leaf',
    ring: 'ring-leaf/30',
    border: 'border-leaf/40',
    icon: Info,
    bg: 'bg-leaf/5',
  },
}

export default function App() {
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState([])
  const [focused, setFocused] = useState(false)

  const results = useMemo(() => searchSubstances(query).filter((s) => !selected.includes(s.id)), [query, selected])
  const interactions = useMemo(() => findInteractions(selected), [selected])

  const addSubstance = (id) => {
    setSelected((prev) => (prev.includes(id) ? prev : [...prev, id]))
    setQuery('')
  }

  const removeSubstance = (id) => setSelected((prev) => prev.filter((s) => s !== id))

  const counts = useMemo(() => {
    const c = { major: 0, moderate: 0, minor: 0 }
    interactions.forEach((i) => c[i.severity]++)
    return c
  }, [interactions])

  return (
    <div className="min-h-screen relative">
      <div className="grain" />

      {/* Header */}
      <header className="max-w-5xl mx-auto px-6 pt-10 pb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-ink text-bg flex items-center justify-center">
              <Pill className="h-4 w-4" strokeWidth={2.2} />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="font-display text-xl font-medium tracking-tight">Interax</span>
              <span className="text-[10px] uppercase tracking-[0.15em] text-muted">v0.1 · lifestyle tool</span>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-xs text-muted">
            <div className="h-1.5 w-1.5 rounded-full bg-leaf animate-pulse" />
            not clinical advice
          </div>
        </div>
      </header>

      {/* Hero + search */}
      <section className="max-w-5xl mx-auto px-6 pb-12">
        <div className="max-w-2xl">
          <p className="text-xs uppercase tracking-[0.18em] text-muted mb-4">Interaction Check</p>
          <h1 className="font-display text-5xl sm:text-6xl leading-[0.95] tracking-tight mb-6">
            What happens{' '}
            <em className="italic font-normal text-accent">when</em>
            <br />
            your medicines meet.
          </h1>
          <p className="text-muted text-lg max-w-xl leading-relaxed">
            Add everything you take — prescription drugs, over-the-counter, vitamins, supplements, even your morning coffee. We'll surface the interactions worth knowing about.
          </p>
        </div>

        {/* Search */}
        <div className="mt-10 relative max-w-2xl">
          <div className="flex items-center gap-3 border-b border-line focus-within:border-ink transition-colors">
            <Search className="h-5 w-5 text-muted" strokeWidth={1.8} />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => setFocused(true)}
              onBlur={() => setTimeout(() => setFocused(false), 150)}
              placeholder="Search a medication, vitamin or supplement…"
              className="border-none flex-1 text-lg h-14"
            />
            {query && (
              <button onClick={() => setQuery('')} className="text-muted hover:text-ink">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {focused && results.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-2 bg-bg border border-line rounded-xl shadow-[0_20px_40px_-20px_rgba(0,0,0,0.15)] overflow-hidden z-10 rise">
              {results.map((s) => (
                <button
                  key={s.id}
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => addSubstance(s.id)}
                  className="w-full px-5 py-3 flex items-center justify-between hover:bg-line/40 transition-colors text-left border-b border-line/50 last:border-0"
                >
                  <div>
                    <div className="font-medium text-ink">{s.name}</div>
                    <div className="text-xs text-muted mt-0.5">{s.category}</div>
                  </div>
                  <Plus className="h-4 w-4 text-muted" />
                </button>
              ))}
            </div>
          )}

          {focused && query && results.length === 0 && (
            <div className="absolute left-0 right-0 top-full mt-2 bg-bg border border-line rounded-xl p-5 z-10">
              <p className="text-sm text-muted">No match. The database is curated — common meds and supplements only.</p>
            </div>
          )}
        </div>

        {/* Quick add suggestions */}
        {selected.length === 0 && (
          <div className="mt-8 max-w-2xl">
            <p className="text-xs uppercase tracking-[0.15em] text-muted mb-3">Try adding</p>
            <div className="flex flex-wrap gap-2">
              {['lisdexamfetamine', 'ibuprofen', 'vitamin-d', 'caffeine', 'omega-3', 'sertraline'].map((id) => {
                const s = getById(id)
                return (
                  <button
                    key={id}
                    onClick={() => addSubstance(id)}
                    className="px-4 py-2 rounded-full border border-line hover:border-ink hover:bg-ink hover:text-bg transition-all text-sm"
                  >
                    + {s.name}
                  </button>
                )
              })}
            </div>
          </div>
        )}
      </section>

      {/* Selected list + results */}
      {selected.length > 0 && (
        <section className="max-w-5xl mx-auto px-6 pb-24">
          <div className="grid lg:grid-cols-[1fr_1.4fr] gap-10">
            {/* Left: Your list */}
            <div>
              <div className="flex items-baseline justify-between mb-5">
                <h2 className="font-display text-2xl">Your stack</h2>
                <span className="text-xs text-muted tabular-nums">{selected.length} item{selected.length !== 1 ? 's' : ''}</span>
              </div>
              <div className="space-y-2">
                {selected.map((id, idx) => {
                  const s = getById(id)
                  return (
                    <div
                      key={id}
                      className="group flex items-center justify-between px-4 py-3 rounded-xl border border-line bg-bg hover:border-ink/30 transition-all rise"
                      style={{ animationDelay: `${idx * 40}ms` }}
                    >
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-[10px] text-muted w-5">{String(idx + 1).padStart(2, '0')}</span>
                        <div>
                          <div className="font-medium text-ink">{s.name}</div>
                          <div className="text-xs text-muted">{s.category}</div>
                        </div>
                      </div>
                      <button
                        onClick={() => removeSubstance(id)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-muted hover:text-accent"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  )
                })}
              </div>

              {selected.length >= 2 && (
                <div className="mt-6 p-5 rounded-xl bg-ink text-bg">
                  <p className="text-xs uppercase tracking-[0.15em] text-bg/60 mb-3">Summary</p>
                  <div className="flex items-baseline gap-6">
                    <div>
                      <div className="font-display text-4xl tabular-nums">{interactions.length}</div>
                      <div className="text-xs text-bg/60 mt-1">interaction{interactions.length !== 1 ? 's' : ''} found</div>
                    </div>
                    <div className="flex flex-col gap-1 text-xs">
                      {counts.major > 0 && <div className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-accent" />{counts.major} major</div>}
                      {counts.moderate > 0 && <div className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-amber" />{counts.moderate} moderate</div>}
                      {counts.minor > 0 && <div className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-leaf" />{counts.minor} minor</div>}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Right: Interactions */}
            <div>
              <div className="flex items-baseline justify-between mb-5">
                <h2 className="font-display text-2xl">Interactions</h2>
                {selected.length >= 2 && interactions.length === 0 && (
                  <span className="text-xs text-leaf flex items-center gap-1.5">
                    <CheckCircle2 className="h-3.5 w-3.5" /> None found
                  </span>
                )}
              </div>

              {selected.length < 2 && (
                <Card className="border-dashed">
                  <CardContent className="p-8 text-center">
                    <p className="text-muted text-sm">Add at least two items to check for interactions.</p>
                  </CardContent>
                </Card>
              )}

              {selected.length >= 2 && interactions.length === 0 && (
                <Card>
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className="h-10 w-10 rounded-full bg-leaf/10 flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="h-5 w-5 text-leaf" />
                      </div>
                      <div>
                        <h3 className="font-display text-lg mb-1">No known interactions</h3>
                        <p className="text-sm text-muted leading-relaxed">
                          Nothing flagged between the items on your list in our curated dataset. This doesn't guarantee safety — always check with a pharmacist or clinician for real decisions.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="space-y-3">
                {interactions.map((i, idx) => {
                  const style = SEVERITY_STYLES[i.severity]
                  const Icon = style.icon
                  const a = getById(i.a)
                  const b = getById(i.b)
                  return (
                    <Card
                      key={`${i.a}-${i.b}`}
                      className={`${style.border} ${style.bg} rise`}
                      style={{ animationDelay: `${idx * 60}ms` }}
                    >
                      <CardContent className="p-5">
                        <div className="flex items-start gap-4">
                          <div className={`h-9 w-9 rounded-full ${style.bg} ring-1 ${style.ring} flex items-center justify-center flex-shrink-0`}>
                            <Icon className="h-4 w-4" strokeWidth={2} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-2">
                              <span className={`h-1.5 w-1.5 rounded-full ${style.dot}`} />
                              <span className="text-[10px] uppercase tracking-[0.15em] font-medium">{style.label}</span>
                            </div>
                            <div className="font-display text-lg leading-tight mb-2">
                              {a.name} <span className="text-muted font-sans text-sm italic">with</span> {b.name}
                            </div>
                            <p className="text-sm text-ink/80 leading-relaxed">{i.summary}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Footer disclaimer */}
      <footer className="max-w-5xl mx-auto px-6 pb-10 pt-6 border-t border-line">
        <p className="text-xs text-muted leading-relaxed max-w-3xl">
          <strong className="text-ink">Disclaimer.</strong> Interax is an informational lifestyle tool built on a small curated dataset. It is not a medical device, not exhaustive, and not a substitute for professional pharmacist or clinician review. Do not make medication decisions based on this app.
        </p>
      </footer>
    </div>
  )
}
